﻿
internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Corrio la aplicacions");
    }
}

sealed class ClaseBase
{
    public void test()
    {

    }
    public void moreTesting()
    {

    }
}
/*
class ClaseHijo : ClaseBase
{
}

*/