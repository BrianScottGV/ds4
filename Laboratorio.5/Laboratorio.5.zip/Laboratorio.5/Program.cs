﻿/*declaracion erronea
int valores = [];
*/

/* declaracion valida
 int[] valores;
 */

//int[] valores;

//valores = new int[100];
//valores = new int[20];


//Arreglo multidimensional
//int[] valores1;
//int[] valores2 = new int[50];

//Arreglos multidimensionales o de dimension simpre
//int[,] valores1;
//int[,] valores2 = new int[3, 7];
//int[,,] valores3 = new int[3, 4, 2]; arreglo de tres dimensiones

//Arreglo de arreglos
//int[][] matriz;

//Los arreglos de arreglos se inicializan de manera diferente 
//int[][] matriz = new int[3][];

//for (int i = 0; i < matriz.Length; i++)
//{
//    matriz[i] = new int[4];
//}
