﻿
internal class BucleForEach
{
    static void Main(string[] args)
    {
        string[] frutas = ["manzana", "platano", "naranja"];

        foreach (string fruta in frutas)
        {
            Console.WriteLine(fruta);
        }
    }
}
